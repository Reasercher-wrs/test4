import requests
import json
import time
import hashlib
from tqdm import tqdm
import re
from modelscope import (
    HubApi, snapshot_download, AutoModelForCausalLM, AutoTokenizer, GenerationConfig
)

YOUR_ACCESS_TOKEN = "34ea45f6-f624-4de6-9604-2e378dd4d4f7"

api = HubApi()
api.login(YOUR_ACCESS_TOKEN)

model_dir = snapshot_download("QiYuan-tech/LLM-Detector-Small-zh",revision = "v1.0.0")
tokenizer = AutoTokenizer.from_pretrained(model_dir, trust_remote_code=True)
model = AutoModelForCausalLM.from_pretrained(model_dir, device_map="auto", trust_remote_code=True).eval()

def main():
    with open('test3.json', 'r', encoding='utf-8') as file:
        data = json.load(file)
    
    t = 0
    a = 0
    for i in tqdm(range(len(data))):
        prompt = data[i]["text"]
        
        response, history = model.chat(tokenizer, prompt, history=None)
        
        if response=="Human":
            true_label = 0
        if response=="AI":
            true_label = 1
        
        print(response)
        
        if true_label==data[i]["label"]:
            t = t+1
        a = a+1
    
    print("ACC: ", (t/a))

'''
        info = {
                "id": test_id,
                "model_answer": final_result
            }
        results.append(info)
        
    with open('output.json', 'w', encoding="utf-8") as f1:
        json.dump(results, f1, ensure_ascii=False, indent=4)
'''

if __name__ == "__main__":
    main()


              